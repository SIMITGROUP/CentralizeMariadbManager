<?php

include "setting.php";
include "functions.php";
session_start();