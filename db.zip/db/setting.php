<?php
$topfolder = explode('/',$_SERVER['REQUEST_URI'])[1];
$ssosetting =[
    'authServerUrl'         => 'http://192.168.0.200/auth',
    'realm'                 => 'int.mydomain.com',
    'clientId'              => 'dba-sso',
    'clientSecret'          => 'xxxxxxxxx',
    'redirectUri'           => 'http://192.168.0.100/'.$topfolder.'/index.php',
    'encryptionAlgorithm'   => 'RS256',                             // optional
 //   'encryptionKeyPath'     => '../key.pem'                         // optional
  //  'encryptionKey'         => 'contents_of_key_or_certificate'     // optional
];


$serverlist =  [
       'db1'=>['server'=>'192.168.0.10','driver'=>'server'],
       'db2'=>['server'=>'192.168.0.11','driver'=>'server'],
   ];
