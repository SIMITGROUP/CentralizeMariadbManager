<?php
include 'system.php';
require_once "./vendor/autoload.php";
$provider = new Stevenmaguire\OAuth2\Client\Provider\Keycloak($ssosetting);

if (!isset($_GET['code'])) {

    // If we don't have an authorization code then get one
    $authUrl = $provider->getAuthorizationUrl();
    $_SESSION['oauth2state'] = $provider->getState();
    header('Location: '.$authUrl);
    exit;

// Check given state against previously stored one to mitigate CSRF attack
} elseif (empty($_GET['state']) || ($_GET['state'] !== $_SESSION['oauth2state'])) {

	unset($_SESSION['oauth2state']);   
	$authurl=$ssosetting['authServerUrl'];
	$realm=$ssosetting['realm'];
	$redirectUri=$ssosetting['redirectUri'];
	$logouturl=$authurl.'/realms/'.$realm.'/protocol/openid-connect/logout?redirect_uri='.$redirectUri;
	echo 'you using session uid:"'.$_SESSION['uid'].'"<br/>';
	exit("invalid state, <a href='$logouturl'>logout url</a> ");
	//	    redirect_header('index.php');

} else {

    // Try to get an access token (using the authorization coe grant)
    try {
        $token = $provider->getAccessToken('authorization_code', [
            'code' => $_GET['code']
        ]);
    } catch (Exception $e) {
        exit('Failed to get access token: '.$e->getMessage());
    }

    // Optional: Now you have a token you can look up a users profile data
    try {

        // We got an access token, let's now get the user's details
        $user = $provider->getResourceOwner($token);
	$userinfo=$user->toArray();
	$uid=$userinfo['preferred_username'];
	// Use these details to create a new profile
	$_SESSION['uid']=$uid;
	redirect_header('adminer.php');
    } catch (Exception $e) {
        exit('Failed to get resource owner: '.$e->getMessage());
    }
	 echo $token->getToken();
    // Use this to interact with an API on the users behalf
}

