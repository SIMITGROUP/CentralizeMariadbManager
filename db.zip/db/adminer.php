<?php

include "system.php";
if(!isset($_SESSION['uid']))
{
	echo 'you cannot login this link';die;
}

function adminer_object()
{
	global $serverlist;
            // required to run any plugin
            include_once "./plugins/plugin.php";
            foreach (glob("plugins/*.php") as $filename)
            {
                        include_once "./$filename";
             }

	    $plugins = array(
		    new AdminerLoginServers($serverlist),
               );

              return new AdminerPlugin($plugins);
}


include "originaladminer.php";